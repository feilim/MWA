    // create a module using the Angular objects module() method
    var myApp = angular.module("myModule",[]);